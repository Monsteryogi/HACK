package com.example.jeet.hack;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.support.v7.widget.Toolbar;

public class Menu extends AppCompatActivity {


    private Toolbar mToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        mToolbar=(Toolbar) findViewById(R.id.menu_app_bar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Menu");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    public void create_project(View v){
        Intent i= new Intent(Menu.this,CreateActivity.class);
        startActivity(i);
    }


    public void land_app(View v){
        Intent i= new Intent(Menu.this,CreateActivity.class);
        startActivity(i);
    }
}
