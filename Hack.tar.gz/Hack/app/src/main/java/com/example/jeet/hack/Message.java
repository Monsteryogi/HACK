package com.example.jeet.hack;

/**
 * Created by Jeet on 3/10/2018.
 */

public class Message {

    public int msgimgs;
    public String headlines;
    public String msgs;


}
