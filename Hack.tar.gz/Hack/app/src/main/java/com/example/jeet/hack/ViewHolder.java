package com.example.jeet.hack;

import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Jeet on 3/10/2018.
 */

public class ViewHolder extends RecyclerView.ViewHolder {

    public ImageView msgimg;
    public TextView headline;
    public TextView msg;

    public ViewHolder(View itemView) {
        super(itemView);

        msgimg = (ImageView) itemView.findViewById(R.id.msgimg);
        headline = (TextView) itemView.findViewById(R.id.headline);
        msg = (TextView) itemView.findViewById(R.id.msg);

    }

}
