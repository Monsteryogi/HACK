package com.example.jeet.hack;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

public class Land_activity extends AppCompatActivity {

    private Toolbar mToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_land_activity);

        mToolbar = (Toolbar) findViewById(R.id.land_app_bar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Land Applications");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }
}
