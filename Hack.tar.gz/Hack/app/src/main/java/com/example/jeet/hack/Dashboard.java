package com.example.jeet.hack;

import android.content.Intent;
import android.graphics.Color;
import android.provider.ContactsContract;
import android.sax.RootElement;
import android.support.annotation.IntDef;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Dashboard extends AppCompatActivity {


    private PieChart mChart;
    RecyclerView recyclerView;

    int chartvalues[] = {1,1, 1, 1};

    TextView app_count, app_pending, app_approved, app_rejected;

    InputStream is = null;
    String line = null;
    String result = null;
    String[] data;

    ImageButton button;

    String[] Headlines = {
            "Lorem Ipsum",
            "Lorem Ipsum",
            "Lorem Ipsum",
            "Lorem Ipsum",
    };

    String[] Message = {
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    };

    int[] Image = {

            R.mipmap.newmsg,
            R.mipmap.star,
            R.mipmap.newmsg,
            R.mipmap.newmsg,
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);


        mChart=(PieChart) findViewById(R.id.chart);
        mChart.setBackgroundColor(Color.WHITE);

        moveOfScreen();
        mChart.setUsePercentValues(false);
        mChart.getDescription().setEnabled(false);
        mChart.setDrawHoleEnabled(true);
        mChart.setMaxAngle(180);
        mChart.setRotationAngle(180);
        mChart.setCenterTextOffset(0,-10);
        mChart.setRotationEnabled(false);
        mChart.animateY(1000, Easing.EasingOption.EaseInOutCubic);
        setdata(4,100);



        /*recyclerView = (RecyclerView) findViewById(R.id.recyclerview);

        List<Message> sampleMsg = new ArrayList<>();
*/
        button = (ImageButton) findViewById(R.id.appbar);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Dashboard.this, Menu.class);
                startActivity(intent);
            }
        });


        /*for (int i = 0; i < Headlines.length; i++) {

            Message message = new Message();

            message.msgimgs = Image[i];
            message.headlines = Headlines[i];
            message.msgs = Message[i];

            sampleMsg.add(message);

        }

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(new RecyclerAdapter(sampleMsg));

        app_count = (TextView) findViewById(R.id.app_count);
        app_pending = (TextView) findViewById(R.id.app_pending);
        app_approved = (TextView) findViewById(R.id.app_approved);
        app_rejected = (TextView) findViewById(R.id.app_rejected);

        //getdata();
    }*/

    /*private void getdata() {
        try {
            URL url = new URL("https://projectbvm.000webhostapp.com/applicationlist.php");
            HttpURLConnection conn=(HttpURLConnection) url.openConnection();

            conn.setRequestMethod("GET");

            is=new BufferedInputStream(conn.getInputStream());

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try{

            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();

            while ((line=br.readLine()) != null){
                sb.append(line+"\n");
            }

            is.close();
            result=sb.toString();

        }catch (Exception e){
            e.printStackTrace();
        }

        try{
            JSONArray js = new JSONArray();
            JSONObject jo = null;

            data = new String[js.length()];

            for (int i=0; i<js.length();i++){
                jo=js.getJSONObject(i);
                data[i]=jo.getString("");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }*/
    }


    String[] approvels=new String[]{"Land Application","Sugarcane Factory","Construction","Petroleum"};
    private void setdata(int count,int range){
        ArrayList<PieEntry> values=new ArrayList<>();

        for (int i=0; i<count;i++){
            //float val= (float)((Math.random()*range)+range/3);
            values.add(new PieEntry(chartvalues[i],approvels[i]));

        }
        PieDataSet dataset=new PieDataSet(values,"Partener");
        dataset.setSelectionShift(5f);
        dataset.setSliceSpace(3f);
        dataset.setColors(ColorTemplate.MATERIAL_COLORS);

        PieData data = new PieData(dataset);
        //data.setValueFormatter(new PercentFormatter());
        data.setValueTextSize(15f);
        data.setValueTextColor(Color.WHITE);

        mChart.setData(data);

        mChart.invalidate();
    }

    private  void moveOfScreen(){
        Display display=getWindowManager().getDefaultDisplay();
        DisplayMetrics metrics=new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int height=metrics.heightPixels;

        int offset=(int) (height*0.4);

        RelativeLayout.LayoutParams params=(RelativeLayout.LayoutParams)mChart.getLayoutParams();
        params.setMargins(0,0,0,-offset);
        mChart.setLayoutParams(params);
    }
}
