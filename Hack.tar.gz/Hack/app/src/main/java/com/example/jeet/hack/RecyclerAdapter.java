package com.example.jeet.hack;

import android.support.v7.widget.ListPopupWindow;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

/**
 * Created by Jeet on 3/10/2018.
 */

public class RecyclerAdapter extends RecyclerView.Adapter<ViewHolder> {

    private List<Message> messages;

    public RecyclerAdapter(List<Message> messages) {

        this.messages = messages;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item,parent,false);
        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        Message samplemsg = messages.get(position);

        holder.msgimg.setImageResource(samplemsg.msgimgs);
        holder.headline.setText(samplemsg.headlines);
        holder.msg.setText(samplemsg.msgs);

    }

    @Override
    public int getItemCount() {
        return messages.size();
    }
}
