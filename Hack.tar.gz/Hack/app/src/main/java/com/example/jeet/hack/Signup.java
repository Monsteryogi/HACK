package com.example.jeet.hack;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Signup extends Activity {

    EditText username, usersex, userphoneno, userdob, useremail, userpassword,company,pan_no;

    String Name, Sex, Phoneno, DOB, EmailID, Password,Company,Pan_no;

    Context ctx = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        username = (EditText) findViewById(R.id.username);
        usersex = (EditText) findViewById(R.id.usersex);
        userdob = (EditText) findViewById(R.id.userdob);
        userphoneno = (EditText) findViewById(R.id.userphoneno);
        useremail = (EditText) findViewById(R.id.useremail);
        userpassword = (EditText) findViewById(R.id.userpassword);
        company = (EditText) findViewById(R.id.company_name);
        pan_no = (EditText) findViewById(R.id.pan_no);

        //text button
        TextView textView_login = (TextView) findViewById(R.id.textView_login);
        textView_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Signup.this, Login.class);
                startActivity(intent);
            }
        });
    }

    public void signup(View v){
        Name = username.getText().toString();
        Sex = usersex.getText().toString();
        DOB = userdob.getText().toString();
        Phoneno = userphoneno.getText().toString();
        EmailID = useremail.getText().toString();
        Password = userpassword.getText().toString();
        Company = company.getText().toString();
        Pan_no = pan_no.getText().toString();
        BackGround b = new BackGround();
        b.execute(Name, Sex, DOB, Phoneno, EmailID, Password,Company,Pan_no);
    }

    class BackGround extends AsyncTask<String, String, String>{

        @Override
        protected String doInBackground(String... params) {

            String name = params[0];
            String sex = params[1];
            String dob = params[2];
            String phoneno = params[3];
            String email = params[4];
            String password = params[5];
            int tmp;
            String data="";

            try {
                URL url = new URL("https://projectbvm.000webhostapp.com/register.php");
                String urlParams = "name="+name+"&sex="+sex+"&dob="+dob+"&phoneno="+phoneno+"&email="+email+"&password="+password;

                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setDoOutput(true);
                OutputStream os = httpURLConnection.getOutputStream();
                os.write(urlParams.getBytes());
                os.flush();
                os.close();
                InputStream is = httpURLConnection.getInputStream();

                while ((tmp=is.read())!=-1){
                    data+=(char)tmp;
                }
                is.close();
                httpURLConnection.disconnect();

                return data;

            } catch (MalformedURLException e) {
                e.printStackTrace();
                return "Exception: "+e.getMessage();
            } catch (IOException e) {
                e.printStackTrace();
                return "Exception: "+e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String s) {
            if (s.equals("")){
                s="User Register Successfully.";
            }
            Toast.makeText(ctx, s, Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Signup.this, Login.class);
            startActivity(intent);
        }
    }

}
